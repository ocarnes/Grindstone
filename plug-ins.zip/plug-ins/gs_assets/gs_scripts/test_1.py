class TestClassOne:
    
    
    def __init__(self):
        pass
       
        
    def doCheck(self):
        print "TestClassOne check!"
        
        
def getObject():
    return TestClassOne()