class TestClassTwo:
    
    
    def __init__(self):
        pass
       
        
    def doCheck(self):
        print "TestClassTwo check!"
        
        
def getObject():
    return TestClassTwo()